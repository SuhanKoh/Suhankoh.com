/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","he",{button:"\u05d4\u05db\u05e0\u05e1 \u05e7\u05d8\u05e2 \u05e7\u05d5\u05d3",codeContents:"\u05ea\u05d5\u05db\u05df \u05e7\u05d5\u05d3",emptySnippetError:"\u05e7\u05d8\u05e2 \u05e7\u05d5\u05d3 \u05dc\u05d0 \u05d9\u05db\u05d5\u05dc \u05dc\u05d4\u05d9\u05d5\u05ea \u05e8\u05d9\u05e7.",language:"\u05e9\u05e4\u05d4",title:"\u05e7\u05d8\u05e2 \u05e7\u05d5\u05d3",pathName:"code snippet"});
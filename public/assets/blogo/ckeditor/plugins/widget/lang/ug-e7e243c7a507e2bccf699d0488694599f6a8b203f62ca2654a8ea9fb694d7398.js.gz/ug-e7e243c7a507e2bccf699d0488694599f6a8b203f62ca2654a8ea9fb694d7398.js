/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("widget","ug",{move:"\u064a\u06c6\u062a\u0643\u06d5\u0634\u062a\u06d5 \u0686\u06d0\u0643\u0649\u067e \u0633\u06c6\u0631\u06d5\u06ad"});
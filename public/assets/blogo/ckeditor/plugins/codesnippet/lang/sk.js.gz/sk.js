/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","sk",{button:"Vlo\u017ete uk\xe1\u017eku programov\xe9ho k\xf3du",codeContents:"Obsah k\xf3du",emptySnippetError:"Uk\xe1\u017eka k\xf3du nesmie by\u0165 pr\xe1zdna.",language:"Jazyk",title:"Uk\xe1\u017eka programov\xe9ho k\xf3du",pathName:"uk\xe1\u017eka programov\xe9ho k\xf3du"});
/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","es",{button:"Insertar fragmento de c\xf3digo",codeContents:"Contenido del c\xf3digo",emptySnippetError:"Un fragmento de c\xf3digo no puede estar vac\xedo.",language:"Lenguaje",title:"Fragmento de c\xf3digo",pathName:"fragmento de c\xf3digo"});
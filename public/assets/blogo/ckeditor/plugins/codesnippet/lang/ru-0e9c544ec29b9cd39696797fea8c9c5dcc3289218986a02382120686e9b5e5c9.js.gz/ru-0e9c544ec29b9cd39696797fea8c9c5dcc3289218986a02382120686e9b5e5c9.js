/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","ru",{button:"\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044c \u0441\u043d\u0438\u043f\u043f\u0435\u0442",codeContents:"\u0421\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u0435 \u043a\u043e\u0434\u0430",emptySnippetError:"\u0421\u043d\u0438\u043f\u043f\u0435\u0442 \u043d\u0435 \u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c \u043f\u0443\u0441\u0442\u044b\u043c",language:"\u042f\u0437\u044b\u043a",title:"\u0421\u043d\u0438\u043f\u043f\u0435\u0442",pathName:"\u0441\u043d\u0438\u043f\u043f\u0435\u0442"});
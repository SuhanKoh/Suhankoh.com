/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("widget","el",{move:"\u039a\u03ac\u03bd\u03b5\u03c4\u03b5 \u03ba\u03bb\u03b9\u03ba \u03ba\u03b1\u03b9 \u03c3\u03cd\u03c1\u03b5\u03c4\u03b5 \u03c4\u03bf \u03c0\u03bf\u03bd\u03c4\u03af\u03ba\u03b9 \u03b3\u03b9\u03b1 \u03bd\u03b1 \u03bc\u03b5\u03c4\u03b1\u03ba\u03b9\u03bd\u03ae\u03c3\u03c4\u03b5"});
/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","cs",{button:"Vlo\u017eit \xfaryvek k\xf3du",codeContents:"Obsah k\xf3du",emptySnippetError:"\xdaryvek k\xf3du nem\u016f\u017ee b\xfdt pr\xe1zdn\xfd.",language:"Jazyk",title:"\xdaryvek k\xf3du",pathName:"\xfaryvek k\xf3du"});
/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","ug",{button:"\u0643\u0648\u062f \u067e\u0627\u0631\u0686\u0649\u0633\u0649 \u0642\u0649\u0633\u062a\u06c7\u0631\u06c7\u0634",codeContents:"\u0643\u0648\u062f \u0645\u06d5\u0632\u0645\u06c7\u0646\u0649",emptySnippetError:"\u0643\u0648\u062f \u067e\u0627\u0631\u0686\u0649\u0633\u0649 \u0628\u0648\u0634 \u0642\u0627\u0644\u0645\u0627\u064a\u062f\u06c7",language:"\u062a\u0649\u0644",title:"\u0643\u0648\u062f \u067e\u0627\u0631\u0686\u0649\u0633\u0649",pathName:"\u0643\u0648\u062f \u067e\u0627\u0631\u0686\u0649\u0633\u0649"});
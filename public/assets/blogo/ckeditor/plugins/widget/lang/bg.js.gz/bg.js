/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("widget","bg",{move:"\u041a\u043b\u0438\u043a\u043d\u0438 \u0438 \u0432\u043b\u0430\u0447\u0438, \u0437\u0430 \u0434\u0430 \u043f\u0440\u0435\u043c\u0435\u0441\u0442\u0438\u0448"});
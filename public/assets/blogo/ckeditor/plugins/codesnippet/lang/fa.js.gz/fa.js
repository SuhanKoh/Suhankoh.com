/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","fa",{button:"\u0642\u0631\u0627\u0631 \u062f\u0627\u062f\u0646 \u06a9\u062f \u0642\u0637\u0639\u0647",codeContents:"\u0645\u062d\u062a\u0648\u0627\u06cc \u06a9\u062f",emptySnippetError:"\u06a9\u062f \u0646\u0645\u06cc \u062a\u0648\u0627\u0646\u062f \u062e\u0627\u0644\u06cc \u0628\u0627\u0634\u062f.",language:"\u0632\u0628\u0627\u0646",title:"\u06a9\u062f \u0642\u0637\u0639\u0647",pathName:"\u06a9\u062f \u0642\u0637\u0639\u0647"});
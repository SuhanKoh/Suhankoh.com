/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","hu",{button:"Illeszd be a k\xf3dt\xf6red\xe9ket",codeContents:"K\xf3d tartalom",emptySnippetError:"A k\xf3dt\xf6red\xe9k nem lehet \xfcres.",language:"Nyelv",title:"K\xf3dt\xf6red\xe9k",pathName:"k\xf3dt\xf6red\xe9k"});
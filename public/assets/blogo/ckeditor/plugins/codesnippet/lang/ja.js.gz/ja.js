/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("codesnippet","ja",{button:"\u30b3\u30fc\u30c9\u30b9\u30cb\u30da\u30c3\u30c8\u3092\u633f\u5165",codeContents:"\u30b3\u30fc\u30c9\u5185\u5bb9",emptySnippetError:"\u30b3\u30fc\u30c9\u30b9\u30cb\u30da\u30c3\u30c8\u3092\u5165\u529b\u3057\u3066\u304f\u3060\u3055\u3044\u3002",language:"\u8a00\u8a9e",title:"\u30b3\u30fc\u30c9\u30b9\u30cb\u30da\u30c3\u30c8",pathName:"\u30b3\u30fc\u30c9\u30b9\u30cb\u30da\u30c3\u30c8"});
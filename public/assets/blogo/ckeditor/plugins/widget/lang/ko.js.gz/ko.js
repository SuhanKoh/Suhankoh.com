/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.plugins.setLang("widget","ko",{move:"\uc6c0\uc9c1\uc774\ub824\uba74 \ud074\ub9ad \ud6c4 \ub4dc\ub798\uadf8 \ud558\uc138\uc694"});